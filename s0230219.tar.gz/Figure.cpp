//
// Created by USER on 6/03/2024.
//

#include "Figure.h"
