//
// Created by student on 21/02/24.
//

#ifndef ENGINE_COLOR_H
#define ENGINE_COLOR_H


class Color {
public:
    double red;
    double green;
    double blue;
};


#endif //ENGINE_COLOR_H
