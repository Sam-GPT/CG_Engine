//
// Created by student on 21/02/24.
//

#ifndef ENGINE_POINT2D_H
#define ENGINE_POINT2D_H


class Point2D {
public:
    double x;
    double y;
};


#endif //ENGINE_POINT2D_H
