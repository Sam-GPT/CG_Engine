//
// Created by USER on 6/03/2024.
//

#ifndef ENGINE_FACE_H
#define ENGINE_FACE_H
#include <vector>

class Face {
public:
    std::vector<int> point_indexes;
};


#endif //ENGINE_FACE_H
